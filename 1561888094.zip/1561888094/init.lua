user_permission={
  [1]	= "ACCESS_COARSE_LOCATION" ;
  [2]	= "ACCESS_FINE_LOCATION" ;
  [3]	= "ACCESS_NETWORK_STATE" ;
  [4]	= "ACCESS_WIFI_STATE" ;
  [5]	= "INTERNET" ;
  [6]	= "WRITE_EXTERNAL_STORAGE" ;
  } ;
packagename="com.MyFusApp.myenganswer"
appver="2.6"
appname="21世纪英语报纸答案"
appcode="4"
template="tool"

--require "import" import"loadlayout" import"loadmenu" import"loadbitmap" 